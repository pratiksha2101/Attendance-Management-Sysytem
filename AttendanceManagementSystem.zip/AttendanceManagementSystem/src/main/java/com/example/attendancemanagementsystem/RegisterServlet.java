package com.example.attendancemanagementsystem;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.example.database.db;

/**
 * Servlet implementation class StudentRegisterServlet
 */


	public class RegisterServlet extends HttpServlet {
	    @Override
	    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        String name = request.getParameter("name");
	        String rollno = request.getParameter("rollno");
	        String course = request.getParameter("course");
	        String semester = request.getParameter("semester");
	        String branch = request.getParameter("branch");
	        String username = request.getParameter("username");
	        String password = request.getParameter("password");

	        try {
	            Connection con = db.getConnection();
	            PreparedStatement ps = con.prepareStatement("INSERT INTO students (name, rollno, course, semester, branch, username, password) VALUES (?, ?, ?, ?, ?, ?, ?)");
	            ps.setString(1, name);
	            ps.setString(2, rollno);
	            ps.setString(3, course);
	            ps.setString(4, semester);
	            ps.setString(5, branch);
	            ps.setString(6, username);
	            ps.setString(7, password);
	            ps.executeUpdate();
	            con.close();
	            response.sendRedirect("login.jsp");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }
	}